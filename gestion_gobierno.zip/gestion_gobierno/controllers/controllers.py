# -*- coding: utf-8 -*-
# from odoo import http


# class GestionGobierno(http.Controller):
#     @http.route('/gestion_gobierno/gestion_gobierno/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gestion_gobierno/gestion_gobierno/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('gestion_gobierno.listing', {
#             'root': '/gestion_gobierno/gestion_gobierno',
#             'objects': http.request.env['gestion_gobierno.gestion_gobierno'].search([]),
#         })

#     @http.route('/gestion_gobierno/gestion_gobierno/objects/<model("gestion_gobierno.gestion_gobierno"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gestion_gobierno.object', {
#             'object': obj
#         })
