# -*- coding: utf-8 -*-

from odoo import models, fields, api


class UnidadAdministrativa(models.Model):
    _name = 'gb.unidad.administrativa'
    _description = 'Gestión Gobierno - Unidad Administrativa'

    nombre = fields.Char('Nombre', required = True)
