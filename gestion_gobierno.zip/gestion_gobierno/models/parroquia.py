# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Parroquia(models.Model):
    _name = 'gb.parroquia'
    _description = 'Gestión Gobierno - Parroquia'

    nombre = fields.Char('Nombre', required = True)
