# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Actividad(models.Model):
    _name = 'gb.actividad'
    _description = 'Actividad'
    # _inherit = 'gb.accion.gobierno'
    nombre_actividad = fields.Char('Nombre')

class AccionGobiernoDetalle(models.Model):
    _name = 'gb.accion.gobierno.detalle'
    _description = 'Detalles de Acción'

    descripcion_accion = fields.Char('Descripción de Actividad', default='')
    # gb_actividad_id = fields.Many2one('gb.actividad', 'Actividad')    

class AccionGobierno(models.Model):
    _name = 'gb.accion.gobierno'
    _description = 'Gestión Gobierno - Acción de Gobierno'

    nombre = fields.Char('Nombre', required = True)
    direccion = fields.Text('Dirección')
    monto_inversion = fields.Float('Monto de Inversión', required = True)
    fecha_inicio = fields.Date('Fecha Inicio')
    fecha_fin = fields.Date('Fecha Fin')
    observacion = fields.Text('Observación')
    sector = fields.Char('Sector', required = True)
    referencia_interna = fields.Char('Referencia Interna')
    codigo_barra = fields.Char('Código de Barra')

    # Relación con otros modelos (claves foráneas):
    gb_tipo_accion_id = fields.Many2one('gb.tipo.accion', 'Tipo Acción')
    gb_parroquia_id = fields.Many2one('gb.parroquia', 'Parroquia')
    gb_unidad_contraloria_social_id = fields.Many2one('gb.unidad.contraloria.social', 'Unidad de Contraloría Social')
    gb_unidad_administrativa_id = fields.Many2one('gb.unidad.administrativa', 'Unidad Administrativa')
    gb_status_id = fields.Many2one('gb.status', 'Estatus')

    # Detalle:
    detalles_descripcion_accion = fields.One2many('gb.accion.gobierno.detalle', 'descripcion_accion', string='Detalle de Acción', default='')