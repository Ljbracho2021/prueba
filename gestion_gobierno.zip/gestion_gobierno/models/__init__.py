# -*- coding: utf-8 -*-

from . import accion_gobierno, tipo_accion, parroquia, unidad_contraloria_social, unidad_administrativa, status