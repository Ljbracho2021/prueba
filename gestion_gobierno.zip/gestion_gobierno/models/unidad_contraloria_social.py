# -*- coding: utf-8 -*-

from odoo import models, fields, api


class UnidadContraloriaSocial(models.Model):
    _name = 'gb.unidad.contraloria.social'
    _description = 'Gestión Gobierno - Unidad de Contraloría Social'

    nombre = fields.Char('Nombre', required = True)
