## Module <om_credit_limit>

#### 16.05.2022
#### Version 15.0.4.1.0
##### IMP
- remove same label warning

#### 15.04.2022
#### Version 15.0.3.0.0
##### IMP
- warning and blocking configuration

#### 15.04.2022
#### Version 15.0.2.1.0
##### IMP
- turkish translation
