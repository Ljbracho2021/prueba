# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Sector(models.Model):
    _name = 'gb.sector'
    _description = 'Gestión Gobierno - Sector'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
