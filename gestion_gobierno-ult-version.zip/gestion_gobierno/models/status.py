# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Status(models.Model):
    _name = 'gb.status'
    _description = 'Gestión Gobierno - Status'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
