# -*- coding: utf-8 -*-

from odoo import models, fields, api

class AccionGobierno(models.Model):
    _name = 'gb.accion.gobierno'
    _description = 'Gestión Gobierno - Acción de Gobierno'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
    direccion = fields.Text('Dirección')
    monto_inversion = fields.Float('Monto de Inversión')
    fecha_inicio = fields.Date('Fecha Inicio')
    fecha_fin = fields.Date('Fecha Fin')
    observacion = fields.Text('Observación')
    # sector = fields.Char('Sector')
    referencia_interna = fields.Char('Referencia Interna')
    codigo_barra = fields.Char('Código de Barra')

    # Relación con otros modelos (claves foráneas):
    gb_tipo_accion_id = fields.Many2one('gb.tipo.accion', 'Tipo Acción')
    gb_parroquia_id = fields.Many2one('gb.parroquia', 'Parroquia')
    gb_sector_id = fields.Many2one('gb.sector', 'Sector')
    gb_unidad_contraloria_social_id = fields.Many2one('gb.unidad.contraloria.social', 'Unidad de Contraloría Social')
    gb_unidad_administrativa_id = fields.Many2one('gb.unidad.administrativa', 'Unidad Administrativa')
    gb_status_id = fields.Many2one('gb.status', 'Estatus')
    persona_contacto_id = fields.Many2one('res.partner', 'Persona contacto')

    accion_imagen = fields.Image(string="Imagen", max_width=100,
                                max_height=100)

    # Detalle:
    # detalles_descripcion_accion = fields.One2many('gb.accion.gobierno.detalle', 'descripcion_accion', string='Detalle de Acción')

class AccionGobiernoDetalle(models.Model):
    _name = 'gb.accion.gobierno.detalle'
    _description = 'Detalles de Acción'

    descripcion_accion = fields.Char('Descripción de Actividad')
    # gb_actividad_id = fields.Many2one('gb.actividad', 'Actividad')

""" class Reporte(models.AbstractModel):
    _name = 'report.gb.accion.gobierno.report_template_gb_accion_gobierno'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env[model.model].browse(docids)
        return {
              'doc_ids': docids,
              'doc_model': model.model,
              'docs': docs,
              'data': data,
        }  """