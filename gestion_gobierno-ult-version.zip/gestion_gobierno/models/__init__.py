# -*- coding: utf-8 -*-

from . import accion_gobierno, parroquia, sector, tipo_accion, status, unidad_administrativa, unidad_contraloria_social, actividad