# -*- coding: utf-8 -*-

from odoo import models, fields, api


class TipoAccion(models.Model):
    _name = 'gb.tipo.accion'
    _description = 'Gestión Gobierno - Tipo Acción'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
