# -*- coding: utf-8 -*-

from odoo import models, fields, api

class Actividad(models.Model):
    _name = 'gb.actividad'
    _description = 'Actividad'
    _rec_name = 'nombre_actividad'

    nombre_actividad = fields.Char('Nombre')