# -*- coding: utf-8 -*-

# import base64
# import io
# from odoo import models


# class ActivoGeoXlsx(models.AbstractModel):
#     _name = 'report.it_sala.report_activo_geo_xls'
#     _inherit = 'report.report_xlsx.abstract'

     def generate_xlsx_report(self, workbook, data, activo):
         bold = workbook.add_format({'bold': True})
         format_1 = workbook.add_format({'bold': True, 'align': 'center', 'bg_color': 'yellow'})

         for obj in activo:
             sheet = workbook.add_worksheet(obj.nombre)
             row = 3
             col = 3
             sheet.set_column('D:D', 12)
             sheet.set_column('E:E', 13)

             row += 1
             sheet.merge_range(row, col, row, col + 1, 'ID Card', format_1)

          
             sheet.write(row, col, 'Name', bold)
             sheet.write(row, col + 1, obj.nombre)
           

             row += 2
             sheet.merge_range(row, col, row + 1, col + 1, '', format_1)





