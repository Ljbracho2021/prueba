# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class SalaComuna(models.Model):
    _name = 'sala.comuna'
    _description = 'Gestión Gobierno - comuna'
    _rec_name = 'nombre'

    nombre = fields.Char('Comuna', required = True)
    estado_id = fields.Many2one('sala.estado', 'Estado', default=1)
    municipio_id = fields.Many2one('sala.municipio', 'Municipio',default=1)

    comunidad_ids = fields.One2many('sala.comunidad', 'comuna_id', string="Comunidades")
    calle_ids = fields.One2many('sala.calle', 'comuna_id', string="Calles")

    image = fields.Image(max_width=100, max_height=100, store=True)
    codigo_situr = fields.Char('Código Situr')
    limite_n = fields.Char('Norte')
    limite_s = fields.Char('Sur')
    limite_e = fields.Char('Este')
    limite_o = fields.Char('Oeste')
    superficie = fields.Integer(string='Superficie')
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')

    articulador_line_ids = fields.One2many('comuna.articulador.lines', 'comuna_id',string="Articulador Lines")

    comunidad_count = fields.Integer(string='Nro. Comunidades', compute='_compute_comunidad_count')

    def _compute_comunidad_count(self):
        for rec in self:
            comunidad_count = self.env['sala.comunidad'].search_count([('comuna_id', '=', rec.id)])
            rec.comunidad_count = comunidad_count

    calle_count = fields.Integer(string='Nro. Calles', compute='_compute_calle_count')

    def _compute_calle_count(self):
        for rec in self:
            # calle_count = self.env['sala.calle'].search_count([('comuna_id', '=', rec.id)])
            calle_count = self.env['sala.calle'].search_count([('comunidad_id.comuna_id', '=', rec.id)])
            rec.calle_count = calle_count
    
    casa_count = fields.Integer(string='Nro. Viviendas', compute='_compute_casa_count')

    def _compute_casa_count(self):
        for rec in self:
            casa_count = self.env['sala.casa'].search_count([('calle_id.comunidad_id.comuna_id', '=', rec.id)])
            rec.casa_count = casa_count

    familia_count = fields.Integer(string='Nro. Familias', compute='_compute_familia_count')

    def _compute_familia_count(self):
        for rec in self:
            familia_count = self.env['sala.familia'].search_count([('casa_id.calle_id.comunidad_id.comuna_id', '=', rec.id)])
            rec.familia_count = familia_count

    @api.constrains('nombre')
    def check_nombre(self):
        for rec in self:
            comuna = self.env['sala.comuna'].search([('nombre', '=', rec.nombre), ('id', '!=', rec.id)])
            if comuna:
                raise ValidationError(_("Nombre %s Ya Existe" % rec.nombre))

class ComunaArticuladorLines(models.Model):
    _name = "comuna.articulador.lines"
    _description = "Comuna / Articulador Lines"

    persona_id = fields.Many2one('sala.persona', 'Articulador')
    rol = fields.Selection([
        ('territorial', 'TERRITORIAL'),
        ('institucional', 'INSTITUCIONAL'), 
        ('formador', 'FORMADOR'),
    ], 'Articulador', required=True, default='territorial', tracking=True)
    
    comuna_id = fields.Many2one('sala.comuna', string="Comuna")
