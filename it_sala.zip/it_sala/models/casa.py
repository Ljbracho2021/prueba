# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaCasa(models.Model):
    _name = 'sala.casa'
    _description = 'Gestión Gobierno - casas de Gobierno'
    _rec_name = 'nombre'
    _order = 'calle_id'
  
    nombre = fields.Char('Casa', required = True)

    estado_id = fields.Many2one('sala.estado', 'Estado', default=1)
    municipio_id = fields.Many2one('sala.municipio', 'Municipio',default=1)
    comuna_id = fields.Many2one('sala.comuna', 'Comuna')
    comunidad_id = fields.Many2one('sala.comunidad', 'Comunidad')
    calle_id = fields.Many2one('sala.calle', 'Calle')
   
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    tipo = fields.Selection([
        ('casa', 'CASA'),
        ('quinta', 'QUINTA'),
        ('rancho', 'RANCHO'),
        ('galpon', 'GALPON'),
        ('otro', 'OTRO'),
        ], required=True, tracking=True) 

    
    direccion = fields.Char('Calle/Av/Nro.')
    note = fields.Text('Observaciones')

    familia_ids = fields.One2many('sala.familia', 'casa_id', string="Familias")