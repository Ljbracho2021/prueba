# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaUbch(models.Model):
    _name = 'sala.ubch'
    _description = 'Gestión Gobierno - ubch'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
   
    territorio_id = fields.Many2one('sala.territorio', 'Territorio')
    direccion_id = fields.Many2one(string='Direccion', related='territorio_id.direccion_id', tracking=True, store=True)
    complete_name = fields.Char('Ubicación', related='territorio_id.complete_name', tracking=True, store=True)
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)

    persona_count = fields.Integer(string='Personas Count', compute='_compute_persona_count')
    persona_line_ids = fields.One2many('ubch.persona.lines', 'ubch_id',
                                            string="Persona Lines")

    ras_line_ids = fields.One2many('ubch.ras.lines', 'ubch_id',
                                            string="Rass Lines")
    
    def _compute_persona_count(self):
        for rec in self:
            persona_count = self.env['sala.persona'].search_count([('ubch_id', '=', rec.id)])
            rec.persona_count = persona_count

class UbchPersonaLines(models.Model):
    _name = "ubch.persona.lines"
    _description = "ubches / Lideres Lines"

    persona_id = fields.Many2one('sala.persona', 'Persona')
    rol = fields.Selection([
        ('fiscal popular', 'FORMADOR'),
        ('vocero alimentacion', 'VOCERO ALIMENTACION'), 
        ('responsable comunal', 'RESPONSABLE COMUNAL'),
    ], 'Rol', required=True, default='vocero alimentacion', tracking=True)
    
    ubch_id = fields.Many2one('sala.ubch', string="ubch")

class UbchRasLines(models.Model):
    _name = "ubch.ras.lines"
    _description = "ubches / Lideres patrulla Lines"

    nombre = fields.Char('Rass', required = True)
    
    ubch_id = fields.Many2one('sala.ubch', string="ubch")