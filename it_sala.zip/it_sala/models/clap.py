# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaClap(models.Model):
    _name = 'sala.clap'
    _description = 'Gestión Gobierno - Clap'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
   
    territorio_id = fields.Many2one('sala.territorio', 'Territorio')
    jefe_id = fields.Many2one('sala.persona', 'Jefe')
    complete_name = fields.Char('Ubicación', related='territorio_id.complete_name', tracking=True, store=True)
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    note = fields.Text('Observaciones')
    persona_line_ids = fields.One2many('clap.persona.lines', 'clap_id',
                                            string="Persona Lines")

    calle_line_ids = fields.One2many('clap.calle.lines', 'clap_id',
                                            string="Calles Lines")

class ClapPersonaLines(models.Model):
    _name = "clap.persona.lines"
    _description = "clapes / Lideres Lines"

    persona_id = fields.Many2one('sala.persona', 'Persona')
    rol = fields.Selection([
        ('fiscal popular', 'FORMADOR'),
        ('vocero alimentacion', 'VOCERO ALIMENTACION'), 
        ('responsable comunal', 'RESPONSABLE COMUNAL'),
    ], 'Rol', required=True, default='vocero alimentacion', tracking=True)
    
    clap_id = fields.Many2one('sala.clap', string="clap")

class ClapCalleLines(models.Model):
    _name = "clap.calle.lines"
    _description = "clapes / Lideres Calle Lines"

    persona_id = fields.Many2one('sala.persona', 'Persona')
    calle = fields.Char('Calle/Av/Vereda/Manzana', required = True)
    
    clap_id = fields.Many2one('sala.clap', string="clap")