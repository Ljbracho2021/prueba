# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaParentesco(models.Model):
    _name = 'sala.parentesco'
    _description = 'Gestión Gobierno - parentesco'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)
   
    parent_id = fields.Many2one('sala.parentesco', 'parentesco Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.parentesco', 'parent_id', 'accionS HIJOS')
    complete_name = fields.Char('parentesco', compute='_compute_complete_name', recursive=True, store=True)     
   
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for parentesco in self:
            if parentesco.parent_id:
                parentesco.complete_name = '%s / %s' % (parentesco.parent_id.complete_name, parentesco.nombre)
            else:
                parentesco.complete_name = parentesco.nombre

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return