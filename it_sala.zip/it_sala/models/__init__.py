# -*- coding: utf-8 -*-

from . import ubicacion, territorio, persona, activo, accion, sector, direccion, organizacion, rol, caso, clap, ubch, calle, casa, familia
from . import estado
from . import municipio
from . import comuna
from . import comunidad
from . import unidad
from . import categoria
from . import centro
from . import tipoa
from . import acciong
from . import tipov
from . import parentesco
from . import parroquia
from . import aparroquia



