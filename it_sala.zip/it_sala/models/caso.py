# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class SalaCaso(models.Model):
    _name = "sala.caso"
   
    _description = "Sala Casos"
    _order = "name"
  
    name = fields.Char(string='Nro.', required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))

    persona_id = fields.Many2one('sala.persona', 'Persona', required=True)
    date_apertura = fields.Date(string="Fecha de apertura")
    date_cierre = fields.Date(string="Fecha de cierre", readonly = "1")
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)   

    clasificacion = fields.Selection([
        ('persona', 'PERSONA'),
        ('familia', 'FAMILIA'),
        ('comunidad', 'COMUNIDAD'),
    ], required=True, default='persona', tracking=True)
    prioridad = fields.Selection([
        ('baja', 'BAJA'),
        ('media', 'MEDIA'),
        ('alta', 'ALTA'),
    ], required=True, default='baja', tracking=True)
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')

    vulnera_line_ids = fields.One2many('caso.vulnera.lines', 'caso_id',
                                            string="Vulnerabilidad")
                                            
    state = fields.Selection([('borrador', 'Borrador'), ('confirmado', 'Confirmado'),
                              ('atendido', 'Atendido'), ('cancelado', 'Cancelado')], default='borrador',
                             string="Status", tracking=True)       

    def action_confirm(self):
        self.state = 'confirmado'

    def action_done(self):
        self.state = 'atendido'

    def action_draft(self):
        self.state = 'borrador'

    def action_cancel(self):
        self.state = 'cancelado'     

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('sala.caso') or _('New')
        res = super(SalaCaso, self).create(vals)
        return res

class casoVulneraLines(models.Model):
    _name = "caso.vulnera.lines"
    _description = "Casos / Vulnera Lines"

   
    vulnerabilidad = fields.Selection([
        ('hipertension', 'HIPERTENSION'),
        ('diabetes', 'DIABETES'),
        ('discapacidad', 'DISCAPACIDAD'),
        ('otro', 'OTRO'),
    ], required=True, tracking=True) 
    observacion = fields.Char(string="Observaciones", required=True) 
    caso_id = fields.Many2one('sala.caso', string="caso")
