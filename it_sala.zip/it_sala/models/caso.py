# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class SalaCaso(models.Model):
    _name = "sala.caso"
   
    _description = "Sala Casos"
    _order = "name"
  
    name = fields.Char(string='Nro.', required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))

    nombre = fields.Char('Acciòn', required = True)                   

    persona_id = fields.Many2one('sala.persona', 'Persona')
    activo_id = fields.Many2one('sala.activo', 'Activo de gobierno')
    
    territorio_id = fields.Many2one(string='Territorio', related='activo_id.territorio_id', tracking=True, store=True)
    estado_id = fields.Many2one(string='Estado', related='territorio_id.estado_id', tracking=True, store=True)
    municipio_id = fields.Many2one(string='Municipio', related='territorio_id.municipio_id', tracking=True, store=True)
    comuna_id = fields.Many2one(string='Comuna', related='territorio_id.comuna_id', tracking=True, store=True)
    comunidad_id = fields.Many2one(string='Comunidad', related='territorio_id.comunidad_id', tracking=True, store=True)
    direccion_id = fields.Many2one(string='Direcciòn', related='territorio_id.direccion_id', tracking=True, store=True)

    image_antes = fields.Image(string="Imagen antes", max_width=100, max_height=100, store=True)
    image_despues = fields.Image(string="Imagen despuès", max_width=100, max_height=100, store=True)
    date_apertura = fields.Date(string="Fecha de apertura")
    date_cierre = fields.Date(string="Fecha de cierre", readonly = "1")
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)   
    avance_porc = fields.Float(string='% Avance')
    monto = fields.Float(string='Monto')
    prioridad = fields.Selection([
        ('baja', 'BAJA'),
        ('media', 'MEDIA'),
        ('alta', 'ALTA'),
    ], required=True, default='baja', tracking=True)
    active = fields.Boolean(string="Active", default=True)

    is_persona = fields.Boolean(string="Persona", default=False)
    is_activo = fields.Boolean(string="Activo de gobierno", default=False)
    is_familia = fields.Boolean(string="Familia", default=False)

    note = fields.Text('Observaciones')

    accion_line_ids = fields.One2many('caso.accion.lines', 'caso_id',
                                            string="Tipo de acciones")
                                            
    state = fields.Selection([('en estudio', 'EN ESTUDIO'), ('confirmado', 'Confirmado'),
                              ('atendido', 'ATENDIDO'), ('cancelado', 'Cancelado')], default='en estudio',
                             string="Status", tracking=True)       

    def action_confirm(self):
        self.state = 'confirmado'

    def action_done(self):
        self.state = 'atendido'

    def action_draft(self):
        self.state = 'en estudio'

    def action_cancel(self):
        self.state = 'cancelado'     

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('sala.caso') or _('New')
        res = super(SalaCaso, self).create(vals)
        return res

class casoAccionLines(models.Model):
    _name = "caso.accion.lines"
    _description = "Casos / Accion Lines"

    accion_id = fields.Many2one('sala.accion', 'Tipo acción')
    cantidad = fields.Integer('Cantidad', default=0)
    avance_porc = fields.Float(string='% Avance')
    observacion = fields.Char(string="Observaciones") 
    caso_id = fields.Many2one('sala.caso', string="caso")

class casoVulneraLines(models.Model):
    _name = "caso.vulnera.lines"
    _description = "Casos / Vulnera Lines"

    observacion = fields.Char() 
    caso_id = fields.Many2one('sala.caso', string="caso")
