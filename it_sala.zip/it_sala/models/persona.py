# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaPersona(models.Model):
    _name = 'sala.persona'
    _description = 'Gestión Gobierno - Personas'
    _rec_name = 'apellido'
    _order = 'apellido, nombre'
  
    nombre = fields.Char('Nombres', required = True)
    apellido = fields.Char('Apellidos', required = True)
    nacionalidad = fields.Selection([
        ('v', 'V'),
        ('e', 'E'),
    ], 'Nacionalidad', default='v', tracking=True, required = True)
    cedula_id = fields.Char('Cédula Identidad', size=12, copy=False, index=True, required = True)
    direccion_id = fields.Many2one('sala.direccion', 'Direcciòn', required = True)

    territorio_id = fields.Many2one(string='Territorio', related='direccion_id.territorio_id', tracking=True, store=True)
       
    estado_id = fields.Many2one(string='Estado', related='territorio_id.estado_id', tracking=True, store=True)
    municipio_id = fields.Many2one(string='Municipio', related='territorio_id.municipio_id', tracking=True, store=True)
    comuna_id = fields.Many2one(string='Comuna', related='territorio_id.comuna_id', tracking=True, store=True)
    comunidad_id = fields.Many2one(string='Comunidad', related='territorio_id.comunidad_id', tracking=True, store=True)
    centro_id = fields.Many2one('sala.centro', 'Centro de votación')
    ubch_id = fields.Many2one(string='Ubch', related='centro_id.ubch_id', tracking=True, store=True, required = True)

    complete_name = fields.Char('Nombre completo', store=True)
    sexo = fields.Selection([
        ('masculino', 'MASCULINO'),
        ('femenino', 'FEMENINO'),
        ('otro', 'OTRO'),
    ], required=True, default='masculino', tracking=True)
    clasificacion = fields.Selection([
        ('persona', 'PERSONA'),
        ('lider', 'LIDER'),
        ('otro', 'OTRO'),
    ], required=True, default='persona', tracking=True)
    prioridad = fields.Selection([
        ('baja', 'BAJA'),
        ('media', 'MEDIA'),
        ('alta', 'ALTA'),
    ], required=True, default='baja', tracking=True)
    image = fields.Image(max_width=100, max_height=100, store=True)

    direccion = fields.Char('Direcciòn adicional')
    calle_id = fields.Many2one('sala.calle', 'Calle', required = True)

    casa = fields.Char('Casa #')
    fecha_nac = fields.Date('Fecha Nacimiento')
    telefono_movil = fields.Char('Teléfono Móvil')
    telefono_fijo = fields.Char('Teléfono Fijo')
    email = fields.Char('e-mail')
    reds_fa = fields.Char('Cuenta Facebook')
    reds_tw = fields.Char('Cuenta Twitter')  
    reds_in = fields.Char('Cuenta Instagram') 
    reds_tl = fields.Char('Cuenta Telegram')   
    istrabaja = fields.Boolean(string="Trabaja", default=True)
    gradoestudio = fields.Selection([
        ('primaria', 'PRIMARIA'),
        ('Secundaria', 'SECUNDARIA'),
        ('universitaria', 'UNIVERSITARIA'),
    ], 'Grado Estudios', default='primaria', tracking=True)
    gruposangre = fields.Selection([
        ('o+', 'O+'),
        ('o-', 'O-'),
        ('a+', 'A+'),
        ('a-', 'A-'),
        ('b+', 'B+'),
        ('b-', 'B-'),  
        ('ab+', 'AB+'),
        ('ab-', 'AB-'),                
    ], 'Grupo sanguineo', default='b+', tracking=True)
    oficio = fields.Char('Profesión/Oficio')
    
    is_jefe = fields.Boolean(string="Es jefe familia?", default=False)
    is_tresmeses = fields.Boolean(string="Recibido beneficios últimos 3 meses?", default=False)
    intencionvoto = fields.Selection([
        ('duro', 'DURO'),
        ('blando', 'BLANDO'),
        ('opositor', 'OPOSITOR'),
    ], 'Caracterización del voto', default='duro', tracking=True)

    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
    notev = fields.Text('Vulnerabilidad')
    accion_ids = fields.One2many('sala.acciong', 'persona_id', string="Acciones de gobierno")

    # persona_line_ids = fields.One2many('familia.persona.lines', 'persona_id', string="Familia Lines")

    vulnera_line_ids = fields.One2many('persona.vulnera.lines', 'persona_id',
                                            string="Tipo de vulnerabilidad")

    familia_line_ids = fields.One2many('persona.familia.lines', 'persona_id',
                                            string="Tipo de familiar")                                        

    accion_count = fields.Integer(string='Nro. acciones', compute='_compute_accion_count')

    def _compute_accion_count(self):
        for rec in self:
            accion_count = self.env['sala.acciong'].search_count([('persona_id', '=', rec.id)])
            rec.accion_count = accion_count

    @api.onchange('cedula_id')
    def _onchange_cedula_id(self):
        if not self.cedula_id:
            return

        domain = [('cedula_id', '=', self.cedula_id)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.persona'].search(domain, limit=1):
            return {'warning': {
                'title': ("Note:"), 
                'message': ("Número de cédula de identidad ya existe ", self.cedula_id), 
            }}


class PersonaVulneraLines(models.Model):
    _name = "persona.vulnera.lines"
    _description = "AccionGobierno / Persona / vulnerabilidad"

    tipov_id = fields.Many2one('sala.tipov', 'Tipo vulnera')
   
    note = fields.Char(string="Observaciones") 
    persona_id = fields.Many2one('sala.persona', string="Persona")   

class PersonaFamiliaLines(models.Model):
    _name = "persona.familia.lines"
    _description = "Familias Lines"

    familiar_id = fields.Many2one('sala.persona', string="Persona")
    parentesco_id = fields.Many2one('sala.parentesco', string="Parentesco")

    persona_id = fields.Many2one('sala.persona', string="Persona")

    
  