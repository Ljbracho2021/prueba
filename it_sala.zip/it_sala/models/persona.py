# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaPersona(models.Model):
    _name = 'sala.persona'
    _description = 'Gestión Gobierno - Personas'
    _rec_name = 'complete_name'
    _order = 'apellido, nombre'
  
    nombre = fields.Char('Nombre', required = True)
    apellido = fields.Char('Apellido', required = True)
    cedula_id = fields.Char('Cédula Identidad', size=12, copy=False, index=True)
    complete_name = fields.Char('Nombre')
    sexo = fields.Selection([
        ('masculino', 'MASCULINO'),
        ('femenino', 'FEMENINO'),
        ('otro', 'OTRO'),
    ], required=True, default='masculino', tracking=True)
    clasificacion = fields.Selection([
        ('persona', 'PERSONA'),
        ('lider', 'LIDER'),
        ('otro', 'OTRO'),
    ], required=True, default='persona', tracking=True)
    prioridad = fields.Selection([
        ('baja', 'BAJA'),
        ('media', 'MEDIA'),
        ('alta', 'ALTA'),
    ], required=True, default='baja', tracking=True)
    image = fields.Image(max_width=100, max_height=100, store=True)
    direccion_id = fields.Many2one('sala.direccion', 'Dirección')
    direccion = fields.Char('Calle/Av/Casa Nro.')
    fecha_nac = fields.Date('Fecha Nacimiento')
    telefono_movil = fields.Char('Teléfono Móvil')
    telefono_fijo = fields.Char('Teléfono Fijo')
    email = fields.Char('e-mail')
    reds_fa = fields.Char('Cuenta Facebook')
    reds_tw = fields.Char('Cuenta Twitter')  
    reds_in = fields.Char('Cuenta Instagram') 
    reds_tl = fields.Char('Cuenta Telegram')   
    istrabaja = fields.Boolean(string="Trabaja", default=True)
    gradoestudio = fields.Selection([
        ('primaria', 'PRIMARIA'),
        ('Secundaria', 'SECUNDARIA'),
        ('universitaria', 'UNIVERSITARIA'),
    ], 'Grado Estudios', default='primaria', tracking=True)

    oficio = fields.Char('Profesión/Oficio')
    dato_medico = fields.Text('Datos Médicos')
    dato_trata = fields.Text('Datos Tratamiento')
    ubch_id = fields.Many2one('sala.ubch', 'Ubch')
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')

    persona_line_ids = fields.One2many('familia.persona.lines', 'persona_id', string="Familia Lines")


    @api.onchange('cedula_id')
    def _onchange_cedula_id(self):
        if not self.cedula_id:
            return

        domain = [('cedula_id', '=', self.cedula_id)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.persona'].search(domain, limit=1):
            return {'warning': {
                'title': ("Note:"), 
                'message': ("Número de cédula de identidad ya existe ", self.cedula_id), 
            }}

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
            if self.apellido:
               self.complete_name = self.apellido.upper() + " , " + self.nombre.upper()
            else:
               self.complete_name = " , " + self.nombre.upper()
         return

    @api.onchange('apellido')
    def _onchange_apellido(self):
         if self.nombre and self.apellido:
            self.apellido = self.apellido.upper()
            self.complete_name = self.apellido.upper() + " , " + self.nombre.upper()
            return

    # def nombre_get(self):
    #     result = []
    #     for rec in self:
    #         nombre = '[' + rec.id + '] ' + rec.nombre
    #         result.append((rec.id, nombre))
    #     return result

    #Método utilizado para personalizar el _rec_name para que muestre nombres y apellidos juntos
    #def name_get(self, cr, uid, ids, context=None):
    #    res = []
    #    registros = self.browse(cr, uid, ids, context)
    #    for registro in registros:
    #        res.append((registro.id, registro.nombre + ' ' + registro.apellidos))
    #    return res
  