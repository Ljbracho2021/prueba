# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaEstado(models.Model):
    _name = 'sala.estado'
    _description = 'Gestión Gobierno - Estados'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
    municipio_ids = fields.One2many('sala.municipio', 'estado_id', string="Municipio")
    