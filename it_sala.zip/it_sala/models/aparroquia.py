# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaAparroquia(models.Model):
    _name = 'sala.aparroquia'
    _description = 'Gestión Gobierno - Analytics Gestion Parroquia'
    _rec_name = 'nombre'

    nombre = fields.Char('Comuna')

    parroquia_id = fields.Many2one('sala.parroquia', 'Parroquia')

    comuna_count = fields.Integer(string='Nro. Comunas', compute='_compute_comuna_count')
 
    def _compute_comuna_count(self):
        for rec in self:
            comuna_count = self.env['sala.comuna'].search_count([('parroquia_id', '=', rec.parroquia_id)])
            rec.comuna_count = comuna_count
     
    