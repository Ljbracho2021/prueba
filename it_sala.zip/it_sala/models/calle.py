# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaCalle(models.Model):
    _name = 'sala.calle'
    _description = 'Gestión Gobierno - calles de Gobierno'
    _rec_name = 'nombre'
    _order = 'nombre'
  
    nombre = fields.Char('Calle', required = True)

    estado_id = fields.Many2one('sala.estado', 'Estado', default=1)
    municipio_id = fields.Many2one('sala.municipio', 'Municipio',default=1)
    comuna_id = fields.Many2one('sala.comuna', 'Comuna')
    comunidad_id = fields.Many2one('sala.comunidad', 'Comunidad')
   
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    tipo = fields.Selection([
        ('calle', 'CALLE'),
        ('avenida', 'AVENIDA'),
        ('manzana', 'MANZANA'),
        ('vereda', 'VEREDA'),
        ('callejon', 'CALLEJON'),
        ('otro', 'OTRO'),
        ], required=True, tracking=True) 
   
    direccion = fields.Char('Calle/avenida/')
    note = fields.Text('Observaciones')

    casa_ids = fields.One2many('sala.casa', 'calle_id', string="Casas")

    casa_count = fields.Integer(string='Nro. Casas', compute='_compute_casa_count')

    def _compute_casa_count(self):
        for rec in self:
            casa_count = self.env['sala.casa'].search_count([('calle_id', '=', rec.id)])
            rec.casa_count = casa_count
