# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SalaRolr(models.Model):
    _name = 'sala.rol'
    _description = 'Gestión Gobierno - Roles'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
    clasificacion = fields.Selection([
        ('consejo comunal', 'CONSEJO COMUNAL'),
        ('clap', 'CLAP'),
        ('ubch', 'UBCH'),
    ], required=True, default='masculino', tracking=True)