# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaCentro(models.Model):
    _name = 'sala.centro'
    _description = 'Gestión Gobierno - Centro Votacion'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
    codigo = fields.Char('Código', required = True)


    ubch_id = fields.Many2one('sala.ubch', 'Ubch')

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return