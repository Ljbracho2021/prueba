# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaUnidad(models.Model):
    _name = 'sala.unidad'
    _description = 'Gestión Gobierno - Unidad'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)
   
    parent_id = fields.Many2one('sala.unidad', 'unidad Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.unidad', 'parent_id', 'accionS HIJOS')
    complete_name = fields.Char('Unidad', compute='_compute_complete_name', recursive=True, store=True)     
   
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for unidad in self:
            if unidad.parent_id:
                unidad.complete_name = '%s / %s' % (unidad.parent_id.complete_name, unidad.nombre)
            else:
                unidad.complete_name = unidad.nombre

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return

