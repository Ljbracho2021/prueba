# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaTerritorio(models.Model):
    _name = 'sala.territorio'
    _description = 'Gestión Gobierno - Territorio'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)
    tipo = fields.Selection([
        ('municipio', 'MUNICIPIO'),
        ('comuna', 'COMUNA'),
        ('comunidad', 'COMUNIDAD'),
        ('sector', 'SECTOR'),
        ], required=True, default='comuna', tracking=True)    

    parent_id = fields.Many2one('sala.territorio', 'Territorio Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.territorio', 'parent_id', 'TERRITORIOS HIJOS')
    direccion_id = fields.Many2one('sala.direccion', 'Direccion')

    complete_name = fields.Char('Territorio', compute='_compute_complete_name', recursive=True, store=True)
   
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    codigo_situr = fields.Char('Código Situr')
    habitantes_nro = fields.Integer(string='Número Habitantes')
    familias_nro = fields.Integer(string='Número Familias')
    viviendas_nro = fields.Integer(string='Número Viviendas')
    limite_n = fields.Char('Norte')
    limite_s = fields.Char('Sur')
    limite_e = fields.Char('Este')
    limite_o = fields.Char('Oeste')
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
    vd = fields.Integer('Intenciòn Votos Duros', default=0)

    familia_count = fields.Integer(string='Familias Count', compute='_compute_familia_count')

 

    clap_count = fields.Integer('# Territorios' , compute='_compute_clap_count', 
                                      help="El numero de clap de esta ubicacion (Does not consider the children categories)")

    articula_line_ids = fields.One2many('territorio.articulador.lines', 'territorio_id', string="Articuladores Lines")
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for territorio in self:
            if territorio.parent_id:
                territorio.complete_name = '%s / %s' % (territorio.parent_id.complete_name, territorio.nombre)
            else:
                territorio.complete_name = territorio.nombre

   
    def _compute_clap_count(self):
        read_group_res = self.env['sala.clap'].read_group([('territorio_id', 'child_of', self.ids)], ['territorio_id'], ['territorio_id'])
        group_data = dict((data['territorio_id'][0], data['territorio_id_count']) for data in read_group_res)
        for territorio in self:
            clap_count = 0 
            for sub_territorio_id in territorio.search([('id', 'child_of', territorio.ids)]).ids:
                clap_count += group_data.get(sub_territorio_id, 0)
            territorio.clap_count = clap_count

    def _compute_familia_count(self):
        for rec in self:
            familia_count = self.env['sala.familia'].search_count([('complete_name', 'ilike', rec.complete_name)])
            rec.familia_count = familia_count

class TerritorioArticuladorLines(models.Model):
    _name = "territorio.articulador.lines"
    _description = "Territorio Articulador Lines"

    persona_id = fields.Many2one('sala.persona', string="Lider")
    rol = fields.Selection([
        ('territorial', 'TERRITORIAL'),
        ('institucional', 'INSTITUCIONAL'),
        ('psuv', 'PSUV'),
    ], required=True, default='territorial', tracking=True)
    territorio_id = fields.Many2one('sala.territorio', string="Territorio")
 
 
   