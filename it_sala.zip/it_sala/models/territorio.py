# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaTerritorio(models.Model):
    _name = 'sala.territorio'
    _description = 'Gestión Gobierno - Territorio'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)
    tipo = fields.Selection([

        ('estado', 'ESTADO'),
        ('municipio', 'MUNICIPIO'),
        ('comuna', 'COMUNA'),
        ('comunidad', 'COMUNIDAD'),
        ('sector', 'SECTOR'),
        ], required=True, default='comuna', tracking=True)    

    parent_id = fields.Many2one('sala.territorio', 'Territorio Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.territorio', 'parent_id', 'TERRITORIOS HIJOS')
    direccion_id = fields.Many2one('sala.direccion', 'Direccion')

    estado_id = fields.Many2one('sala.estado', 'Estado')
    municipio_id = fields.Many2one('sala.municipio', 'Municipio')
    comuna_id = fields.Many2one('sala.comuna', 'Comuna')
    comunidad_id = fields.Many2one('sala.comunidad', 'Comunidad')

    complete_name = fields.Char('Territorio', compute='_compute_complete_name', recursive=True, store=True)
   
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for territorio in self:
            if territorio.parent_id:
                territorio.complete_name = '%s / %s' % (territorio.parent_id.complete_name, territorio.nombre)
            else:
                territorio.complete_name = territorio.nombre
 
    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return
   

class TerritorioArticuladorLines(models.Model):
    _name = "territorio.articulador.lines"
    _description = "Territorio Articulador Lines"

    nombre = fields.Char('Nombre')
    
    territorio_id = fields.Many2one('sala.territorio', string="Territorio")
 
 
   