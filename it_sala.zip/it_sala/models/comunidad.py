# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaComunidad(models.Model):
    _name = 'sala.comunidad'
    _description = 'Gestión Gobierno - Comunidades'
    _rec_name = 'nombre'
    _order = 'comuna_id , nombre'

    nombre = fields.Char('Comunidad', required = True)
    estado_id = fields.Many2one('sala.estado', 'Estado', default=1)
    municipio_id = fields.Many2one('sala.municipio', 'Municipio',default=1)
    comuna_id = fields.Many2one('sala.comuna', 'Comuna')
    note = fields.Text('Observaciones')

    calle_ids = fields.One2many('sala.calle', 'comunidad_id', string="Calles")

    calle_count = fields.Integer(string='Nro. Calles', compute='_compute_calle_count')

    def _compute_calle_count(self):
        for rec in self:
            calle_count = self.env['sala.calle'].search_count([('comunidad_id', '=', rec.id)])
            rec.calle_count = calle_count