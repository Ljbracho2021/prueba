# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaParroquia(models.Model):
    _name = 'sala.parroquia'
    _description = 'Gestión Gobierno - Parroquia'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)

    estado_id = fields.Many2one('sala.estado', 'Estado')
    municipio_id = fields.Many2one('sala.municipio', 'Municipio')

    comuna_count = fields.Integer(string='Nro. Comunas', compute='_compute_comuna_count')
    def _compute_comuna_count(self):
        for rec in self:
            comuna_count = self.env['sala.comuna'].search_count([('parroquia_id', '=', rec.id)])
            rec.comuna_count = comuna_count
        
    comunidad_count = fields.Integer(string='Nro. Comunidades', compute='_compute_comunidad_count')
    def _compute_comunidad_count(self):
        for rec in self:
            comunidad_count = self.env['sala.comunidad'].search_count([('parroquia_id', '=', rec.id)])
            rec.comunidad_count = comunidad_count

    accion_count = fields.Integer(string='Nro. Acciones de gobierno', compute='_compute_accion_count')
    def _compute_accion_count(self):
        for rec in self:
            accion_count = self.env['sala.acciong'].search_count([('parroquia_id', '=', rec.id)])
            rec.accion_count = accion_count    

    habita_count = fields.Integer(string='Nro. Habitantes', compute='_compute_habita_count')
    def _compute_habita_count(self):
        for rec in self:
            habita_count = self.env['sala.persona'].search_count([('parroquia_id', '=', rec.id)])
            rec.habita_count = habita_count
    
    familia_count = fields.Integer(string='Nro. Familias', compute='_compute_familia_count')
    def _compute_familia_count(self):
        for rec in self:
            familia_count = self.env['sala.persona'].search_count([('parroquia_id', '=', rec.id),('is_jefe', '=', 'true')])
            rec.familia_count = familia_count