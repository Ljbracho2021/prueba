# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class SalaActivo(models.Model):
    _name = 'sala.activo'
    _description = 'Gestión Gobierno - Activos de Gobierno'
    _rec_name = 'nombre'
    _order = 'territorio_id'

    name = fields.Char(string='Nro.', required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))

    nombre = fields.Char('Nombre', required = True)
    codigo = fields.Char('Còdigo')
   
    direccion_id = fields.Many2one('sala.direccion', 'Direccioon', required=True)
    territorio_id = fields.Many2one(string='Territorio', related='direccion_id.territorio_id', tracking=True, store=True)

    estado_id = fields.Many2one(string='Estado', related='territorio_id.estado_id', tracking=True, store=True)
    municipio_id = fields.Many2one(string='Municipio', related='territorio_id.municipio_id', tracking=True, store=True)
    comuna_id = fields.Many2one(string='Comuna', related='territorio_id.comuna_id', tracking=True, store=True)
    comunidad_id = fields.Many2one(string='Comunidad', related='territorio_id.comunidad_id', tracking=True, store=True)
    
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    categoria_id = fields.Many2one('sala.categoria', 'Categoría', required = True)
    
    direccion = fields.Char('Direcciòn adicional')
    latlng = fields.Char('LATLNG')

    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Favorito'),
    ], required=True, default='0', tracking=True)
    active = fields.Boolean(
        'Active', default=True,
        help="If unchecked, it will allow you to hide the product without removing it.")
    note = fields.Text(string=" ")

    accion_ids = fields.One2many('sala.acciong', 'activo_id', string="Acciones")

    accion_count = fields.Integer(string='Nro. acciones', compute='_compute_accion_count')

    def _compute_accion_count(self):
        for rec in self:
            accion_count = self.env['sala.acciong'].search_count([('activo_id', '=', rec.id)])
            rec.accion_count = accion_count

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('sala.activo') or _('New')
        res = super(SalaActivo, self).create(vals)
        return res

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return
    