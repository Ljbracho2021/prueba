# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaActivo(models.Model):
    _name = 'sala.activo'
    _description = 'Gestión Gobierno - Activos de Gobierno'
    _rec_name = 'nombre'
    _order = 'territorio_id'
  
    nombre = fields.Char('Nombre', required = True)
   
    territorio_id = fields.Many2one('sala.territorio', 'Territorio')
    sector_id = fields.Many2one('sala.sector', 'Sector')
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    tipo = fields.Selection([
        ('cancha', 'CANCHA'),
        ('escuela', 'ESCUELA'),
        ('iglesia', 'IGLESIA'),
        ('cdi', 'CDI'),
        ('hospital', 'HOSTITAL'),
        ('casa abuelos', 'CASA ABUELOS'),
        ], required=True, tracking=True) 
    complete_name = fields.Char('Ubicación', related='territorio_id.complete_name', tracking=True, store=True)
    direccion_id = fields.Many2one('sala.direccion', 'Dirección')
    calle_av_casa = fields.Char('Calle/Av/Nro.')
    