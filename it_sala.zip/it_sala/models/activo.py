# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class SalaActivo(models.Model):
    _name = 'sala.activo'
    _description = 'Gestión Gobierno - Activos de Gobierno'
    _rec_name = 'nombre'
    _order = 'territorio_id'

    name = fields.Char(string='Nro.', required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))

    nombre = fields.Char('Nombre', required = True)
   
    territorio_id = fields.Many2one('sala.territorio', 'Territorio', required = True)
    
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    categoria_id = fields.Many2one('sala.categoria', 'Categoria', required = True)
    direccion_id = fields.Many2one(string='Direcciòn', related='territorio_id.direccion_id', tracking=True, store=True)
    
    calle_av_casa = fields.Char('Calle/Av/Nro.')
    latlng = fields.Char('LATLNG')

    accion_count = fields.Integer(string='Nro. acciones', compute='_compute_accion_count')

    def _compute_accion_count(self):
        for rec in self:
            accion_count = self.env['sala.acciong'].search_count([('activo_id', '=', rec.id)])
            rec.accion_count = accion_count

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('sala.activo') or _('New')
        res = super(SalaActivo, self).create(vals)
        return res

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return
    