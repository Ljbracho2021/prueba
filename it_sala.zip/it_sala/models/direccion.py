# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaDireccion(models.Model):
    _name = 'sala.direccion'
    _description = 'Gestión Gobierno - Direccion'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name' 

    name = fields.Char('Nombre', index=True, required=True)
 
    complete_name = fields.Char('Dirección', compute='_compute_complete_name', recursive=True, store=True)
    parent_id = fields.Many2one('sala.direccion', 'Dirección Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    
    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for direccion in self:
            if direccion.parent_id:
                direccion.complete_name = '%s / %s' % (direccion.parent_id.complete_name, direccion.name)
            else:
                direccion.complete_name = direccion.name

    @api.constrains('parent_id')
    def _check_category_recursion(self):
        if not self._check_recursion():
            raise ValidationError(_('You cannot create recursive direccion.'))

    @api.model
    def name_create(self, name):
        return self.create({'name': name}).name_get()[0]

    def name_get(self):
        if not self.env.context.get('hierarchical_naming', True):
            return [(record.id, record.name) for record in self]
        return super().name_get()