# -*- coding: utf-8 -*-

from random import randint

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class SalaAcciong(models.Model):
    _name = "sala.acciong"
   
    _description = "Sala Accion Gobierno"
    _order = "name"
  
    name = fields.Char(string='Nro.', required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))

    nombre = fields.Char('Acciòn', required = True)                   

    persona_id = fields.Many2one('sala.persona', 'Persona')
    activo_id = fields.Many2one('sala.activo', 'Activo de gobierno')

    direccion_id = fields.Many2one('sala.direccion', string='Dirección', store=True)
    territorio_id = fields.Many2one(string='Territorio', related='direccion_id.territorio_id', tracking=True, store=True)
   
    estado_id = fields.Many2one(string='Estado', related='territorio_id.estado_id', tracking=True, store=True)
    municipio_id = fields.Many2one(string='Municipio', related='territorio_id.municipio_id', tracking=True, store=True)
    parroquia_id = fields.Many2one(string='Parroquia', related='territorio_id.parroquia_id', tracking=True, store=True)
    comuna_id = fields.Many2one(string='Comuna', related='territorio_id.comuna_id', tracking=True, store=True)
    comunidad_id = fields.Many2one(string='Comunidad', related='territorio_id.comunidad_id', tracking=True, store=True)

    image_antes = fields.Image(string="Imagen antes", max_width=100, max_height=100, store=True)
    image_despues = fields.Image(string="Imagen despuès", max_width=100, max_height=100, store=True)
    date_apertura = fields.Date(string="Fecha de apertura", required=True, default=fields.Date.today )
    date_cierre = fields.Date(string="Fecha de cierre", required=True, default=fields.Date.today)
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)   
    avance_porc = fields.Float(string='% Avance')
    monto = fields.Float(string='Inversiòn')
    prioridad = fields.Selection([
        ('baja', 'BAJA'),
        ('media', 'MEDIA'),
        ('alta', 'ALTA'),
    ], required=True, default='baja', tracking=True)
    active = fields.Boolean(string="Active", default=True)

    is_persona = fields.Boolean(string="Persona", default=False)
    is_activo = fields.Boolean(string="Activo de gobierno", default=False)
    is_comunidad = fields.Boolean(string="Comunidad", default=False)

    note = fields.Text('Observaciones')

    accion_line_ids = fields.One2many('acciong.lines', 'acciong_id',
                                            string="Tipo de acciones")
    tag_ids = fields.Many2many('sala.tags', string='Etiquetas')
    uni_ids = fields.Many2many('sala.unidad', string='Unidades')
                                            
    state = fields.Selection([('en estudio', 'EN ESTUDIO'), ('aprobada', 'APROBADA'),
                              ('en proceso', 'EN PROCESO'), ('ejecutada', 'EJECUTADA'), ('cancelada', 'CANCELADA')], default='en estudio',
                             string="Status", tracking=True)       

    def action_aprobar(self):
        self.state = 'aprobada'

    def action_proceso(self):
        self.state = 'en proceso'

    def action_done(self):
        self.state = 'ejecutada'

    def action_draft(self):
        self.state = 'en estudio'

    def action_cancel(self):
        self.state = 'cancelada'     

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('sala.acciong') or _('New')
        res = super(SalaAcciong, self).create(vals)
        return res

    # @api.onchange('activo_id')
    # def _onchange_activo_id(self):
         
    #     if self.activo_id:
    #         self.territorio_id = self.activo_id.territorio_id
    #     return

    # @api.onchange('persona_id')
    # def _onchange_persona_id(self):
         
    #     if self.persona_id:
    #         self.territorio_id = self.persona_id.territorio_id
    #     return

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return

class AcciongLines(models.Model):
    _name = "acciong.lines"
    _description = "AccionGobierno / Accion Lines"

    accion_id = fields.Many2one('sala.tipoa', 'Tipo acción')
    unidad_id = fields.Many2one('sala.unidad', 'U/A')
    persona_id = fields.Many2one('sala.persona', 'Beneficiario')

    cantidad = fields.Integer('Cantidad', default=0)
    avance_porc = fields.Float(string='% Avance')
    observacion = fields.Char(string="Observaciones") 

    nombre = fields.Char(string='Nombre', related='acciong_id.nombre', tracking=True, store=True)

    date_apertura = fields.Date(string="Fecha/Apertura", related='acciong_id.date_apertura', tracking=True, store=True )
    date_cierre = fields.Date(string="Fecha/cierre", related='acciong_id.date_cierre', tracking=True, store=True)
    state = fields.Selection(string="Status", related='acciong_id.state', tracking=True, store=True ) 

    territorio_id = fields.Many2one(string='Territorio', related='acciong_id.territorio_id', tracking=True, store=True)
    estado_id = fields.Many2one(string='Estado', related='territorio_id.estado_id', tracking=True, store=True)
    municipio_id = fields.Many2one(string='Municipio', related='territorio_id.municipio_id', tracking=True, store=True)
    parroquia_id = fields.Many2one(string='Parroquia', related='territorio_id.parroquia_id', tracking=True, store=True)
    comuna_id = fields.Many2one(string='Comuna', related='territorio_id.comuna_id', tracking=True, store=True)
    comunidad_id = fields.Many2one(string='Comunidad', related='territorio_id.comunidad_id', tracking=True, store=True)
    activo_id = fields.Many2one(string='Activo', related='acciong_id.activo_id', tracking=True, store=True)

    acciong_id = fields.Many2one('sala.acciong', string="Nro.")

class AcciongTags(models.Model):
     """ Tags of project's tasks """
     _name = "sala.tags"
     _description = "Project Tags"

     def _get_default_color(self):
        return randint(1, 11)

     name = fields.Char('Name', required=True)
     color = fields.Integer(string='Color', default=_get_default_color)

     _sql_constraints = [
         ('name_uniq', 'unique (name)', "Tag name already exists!"),
     ]
