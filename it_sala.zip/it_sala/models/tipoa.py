# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaTipoa(models.Model):
    _name = 'sala.tipoa'
    _description = 'Gestión Gobierno - Tipo Accion'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'nombre_cor'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)

    nombre_cor = fields.Char('Nombre Corto', required = True) 
    parent_id = fields.Many2one('sala.tipoa', 'Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.tipoa', 'parent_id', 'accionS HIJOS')
    complete_name = fields.Char('Tipo acción', compute='_compute_complete_name', recursive=True, store=True)     
   
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for tipoa in self:
            if tipoa.parent_id:
                tipoa.complete_name = '%s / %s' % (tipoa.parent_id.complete_name, tipoa.nombre)
            else:
                tipoa.complete_name = tipoa.nombre

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return