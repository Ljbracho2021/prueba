# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaFamilia(models.Model):
    _name = 'sala.familia'
    _description = 'Gestión Gobierno - familias de Gobierno'
    _rec_name = 'nombre'
    _order = 'casa_id'
  
    nombre = fields.Char('Familia', required = True)
    
    estado_id = fields.Many2one('sala.estado', 'Estado', default=1)
    municipio_id = fields.Many2one('sala.municipio', 'Municipio',default=1)
    comuna_id = fields.Many2one('sala.comuna', 'Comuna')
    comunidad_id = fields.Many2one('sala.comunidad', 'Comunidad')
    calle_id = fields.Many2one('sala.calle', 'Calle')
    casa_id = fields.Many2one('sala.casa', 'Casa')
   
    jefe_id = fields.Many2one('sala.persona', 'Jefe de Familia')
   
    active = fields.Boolean(string="Active", default=True)
    clap_id = fields.Many2one('sala.clap', 'Clap')
    note = fields.Text('Observaciones')

    persona_line_ids = fields.One2many('familia.persona.lines', 'familia_id', string="Familia Lines")

    persona_count = fields.Integer(string='Nro. Personas', compute='_compute_persona_count')

    def _compute_persona_count(self):
        for rec in self:
            persona_count = self.env['familia.persona.lines'].search_count([('familia_id', '=', rec.id)])
            rec.persona_count = persona_count

    @api.onchange('nombre')
    def _onchange_nombre(self):
         if self.casa_id:
            self.comuna_id=self.casa_id.calle_id.comunidad_id.comuna_id
            self.comunidad_id=self.casa_id.calle_id.comunidad_id
            self.calle_id=self.casa_id.calle_id
            return

class FamiliaPersonaLines(models.Model):
    _name = "familia.persona.lines"
    _description = "Familias Lines"

    persona_id = fields.Many2one('sala.persona', string="Familiar")
    isjefe = fields.Boolean(string="Jefe Familia", default=False)
    rol = fields.Selection([
        ('esposo(a)', 'ESPOSO(A)'),
        ('concubino(a)', 'CONCUBINO(A)'),
        ('hijo(a)', 'HIJO(A)'),
        ('hermana', 'HERMANA'),
    ], required=True, default='esposo(a)', tracking=True)
    intencion = fields.Selection([
        ('duro', 'DURO'),
        ('blando', 'BLANDO'),
        ('opositor', 'OPOSITOR'),
    ], required=True, default='duro', tracking=True)

    familia_id = fields.Many2one('sala.familia', string="Familia")

    @api.onchange('nombre')
    def _onchange_nombre(self):
         if self.casa_id:
            self.comuna_id=self.casa_id.calle_id.comunidad_id.comuna_id
            self.comunidad_id=self.casa_id.calle_id.comunidad_id
            self.calle_id=self.casa_id.calle_id
            return 